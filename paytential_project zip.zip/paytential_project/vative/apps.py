from django.apps import AppConfig


class VativeConfig(AppConfig):
    name = 'vative'
